// From: http://sourceforge.net/p/poco/feature-requests/168/

#include "ofx/RecursiveDirectoryIterator.h"


namespace Poco {


}
